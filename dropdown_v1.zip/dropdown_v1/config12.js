function reset() {
//  init();
//  doSomethingElse();
document.getElementById("combo4").disabled = true;
document.getElementById("combo5").disabled = true;
document.getElementById("combo6").disabled = true;
document.getElementById("btn1").disabled = true;
document.getElementById("btn2").disabled = true;
document.getElementById("txtarea").value = "You will see final report script here";
document.getElementById("txtarea").disabled = true; 
document.getElementById("btn3").disabled = true; 
console.log("load event detected");

};

function resetAll()
{
	document.getElementById("combo1").selectedIndex=0;		
	document.getElementById("combo2").options.length=0;		
	document.getElementById("combo3").options.length=0;	
	document.getElementById("btn1").disabled = true;
	document.getElementById("combo4").disabled = true;
	document.getElementById("combo5").disabled = true;
	document.getElementById("combo6").disabled = true;
	document.getElementById("btn1").disabled = true;
	document.getElementById("btn2").disabled = true;
	document.getElementById("txtarea").value = "You will see final report script here";
	document.getElementById("txtarea").disabled = true; 
	document.getElementById("btn3").disabled = true;
	$('#rptresult').html("");
 
}

function enableElement(obj)
{
	obj.disabled = false;
}

function configdropdown(dropdwn1Obj,dropdwn2Obj,dropdwn3Obj)
{
	// to get ID of comobo box selected
	var buttonselected = dropdwn1Obj.id;
	//console.log(buttonselected);	
    var selectIndex = dropdwn1Obj.selectedIndex;
    //console.log(selectIndex);
    var selectValue = dropdwn1Obj.options[selectIndex].text;
    console.log(selectValue);
	
	//var selectIndex0 = dropdwn0Obj.selectedIndex;
    //console.log(selectIndex);
    //var selectValue0 = dropdwn0Obj.options[selectIndex0].text;
    //console.log(selectValue0);
	
	//console.log(dropdwn1Obj.id);	
	
	//var myarray1 = new Array(["opt20","select an option"],["opt21","suboption11"],["opt22","suboption12"]);
	//var myarray2 = new Array(["opt30","select an option"],["opt31","suboption21"],["opt32","suboption32"]);
	
	switch(selectIndex)
	{
		case 0:
			//txtbx.value = "";
			dropdwn2Obj.options.length=0;				
			if(buttonselected == "combo1")
			{
				dropdwn3Obj.options.length=0;		
			}
			break;
		default:
			dropdwn2Obj.options.length=0;	
			if(buttonselected == "combo1")
			{				
				if(appMap.has(selectValue))
				{
					var appName = appMap.get(selectValue);
					//console.log(appName);
					for(i=0;i<appName.length;i++)
					{
						addOption(dropdwn2Obj,appName[i],appName[i]);
					}
				}
			}
			else if(buttonselected == "combo2")
			{				
				if(servMap.has(selectValue))
				{
					var servName = servMap.get(selectValue);
					//console.log(servName);
					for(i=0;i<servName.length;i++)
					{
						addOption(dropdwn2Obj,servName[i],servName[i]);
					}
				}
			}					
			break;
	}
}

function addOption(dropdwnObj,optnValue, optnText)
{
	var opt = document.createElement('option');
	opt.value = optnValue;
	opt.text = optnText;
	if(optnText == "select an option")
	{
		opt.selected="selected";
	}
	dropdwnObj.options.add(opt);
}
/*
function subbttn(dropdwn1Obj,dropdwn2Obj,dropdwn3Obj)
{
	var selectIndex1 = dropdwn1Obj.selectedIndex;
	var selectIndex2 = dropdwn2Obj.selectedIndex;
	var selectIndex3 = dropdwn3Obj.selectedIndex;

	//var txtbx = document.getElementById("txtbox");
	
	if(selectIndex1==0 || selectIndex2==0 || selectIndex3==0)
	{
		alert("Please select values for all dropdowns");
	}
	else
	{
		var selectValue1 = dropdwn1Obj.options[selectIndex1].text;
		var selectValue2 = dropdwn2Obj.options[selectIndex2].text;	
		var selectValue3 = dropdwn3Obj.options[selectIndex3].text;		
		//txtbx.value = selectValue1+selectValue2+selectValue3;
		var dropdwn4Obj = document.getElementById("combo4");
		var dropdwn5Obj = document.getElementById("combo5");
		var dropdwn6Obj = document.getElementById("combo6");
		//document.getElementById("btn2").disabled = false;
		dropdwn4Obj.disabled = false;
		dropdwn5Obj.disabled = false;
		dropdwn6Obj.disabled = false;
		
		setDateRange(selectValue3);
	}
}
*/
function generateReport()
{	
	var dropdwn3Obj = document.getElementById("combo3");
	var dropdwn4Obj = document.getElementById("combo4");
	var dropdwn5Obj = document.getElementById("combo5");
	var dropdwn6Obj = document.getElementById("combo6");
	
	var timeRangeIndex =  dropdwn4Obj.selectedIndex;
	var highLevelIndex = dropdwn5Obj.selectedIndex;
	var lowLeveIndex = dropdwn6Obj.selectedIndex;
	
	var txtarea = document.getElementById("txtarea"); 
	txtarea.value = "";
	if(timeRangeIndex == 0 || highLevelIndex == 0)
	{
		alert("Date Range and High Level values is mandatory!!");
	}
	else
	{
		var dbName = dropdwn3Obj.options[dropdwn3Obj.selectedIndex].text;
		var dateRange = dropdwn4Obj.options[dropdwn4Obj.selectedIndex].value;
		var highLevel = dropdwn5Obj.options[dropdwn5Obj.selectedIndex].text;
		var lowLevel = dropdwn6Obj.options[dropdwn6Obj.selectedIndex].text;
		if(lowLevel == "select an option")
		{
			lowLevel = "Not applicable";
		}
		
		txtarea.value = "Database Name : "+ dbName + "\nDate Range : "+dateRange +"\nHigh Level : "+highLevel +"\nLow level :"+lowLevel;
		//txtarea.value = "Database Name : "+ dbName + " Date Range : "+dateRange +" High Level : "+highLevel +" Low level :"+lowLevel;
		document.getElementById("btn3").disabled = false; 
	}
	
	
}
