$(document).ready(function(){
	/* Report script generation */
	$('#btn3').on('click',function (e){
		//ajaxProgressMsg = "";
		var reportQuery = "";
		ajaxProgressMsg = "Report execution and data retrevial in progress.. please wait.. ";
		ajaxErrorMsg = "Issue in report execution and data retrevial.";
		console.log("in btn3 : "+ajaxProgressMsg);
		reportQuery = document.getElementById("txtarea").value;
		//alert("Hi clicked me");
		$.ajax({
			type:"POST",
			url:'/AjaxTest/ReportServletHandler',
			data: {Query:reportQuery},
			//data:"",
			success: function(result){
				//alert("Hi!! in success");
				$('#rptresult').html(result);
			}
		});
	});
	/* Key measure dropdown population */
	$('#btn1').on('click',function (e){
		ajaxProgressMsg = "Keymeasure dimension value retrevial in progress.. please wait..";
		ajaxErrorMsg = "Issue in Keymeasure dimension value retrevial.";
		var dropdwn1Obj = document.getElementById("combo1");
		var dropdwn2Obj = document.getElementById("combo2");
		var dropdwn3Obj = document.getElementById("combo3");
		var dropdwn4Obj = document.getElementById("combo4");
		var dropdwn5Obj = document.getElementById("combo5");
		var dropdwn6Obj = document.getElementById("combo6");
		var selectIndex1 = dropdwn1Obj.selectedIndex;
		var selectIndex2 = dropdwn2Obj.selectedIndex;
		var selectIndex3 = dropdwn3Obj.selectedIndex;

		//var txtbx = document.getElementById("txtbox");
		
		if(selectIndex1==0 || selectIndex2==0 || selectIndex3==0)
		{
			alert("Please select values for all dropdowns");
		}
		else
		{

			
			var selectValue1 = dropdwn1Obj.options[selectIndex1].text;
			var selectValue2 = dropdwn2Obj.options[selectIndex2].text;	
			var selectValue3 = dropdwn3Obj.options[selectIndex3].text;		
			//txtbx.value = selectValue1+selectValue2+selectValue3;
			//alert(selectValue3);

			//document.getElementById("btn2").disabled = false;
			dropdwn4Obj.disabled = false;
			dropdwn5Obj.disabled = false;
			dropdwn6Obj.disabled = false;
			//var dbName = "";
			//var dropdwn3Obj = document.getElementById("combo3");
			//var selectIndex3 = dropdwn3Obj.selectedIndex;
			//var selectValue3 = dropdwn3Obj.options[selectIndex3].text;
			//alert("Hi clicked me");
			$.ajax({
				type:"GET",
				url:'/AjaxTest/DropDownHandler',
				data: {dbname:selectValue3},
				dataType:'json',
				success: function(result)
				{
					//alert("Hi!! in success");
		            $("#combo4").get(0).options.length = 0;
		            $("#combo4").get(0).options[0] = new Option("Select an option", "-1");   
					console.log(Object.keys(result));
					for (var key in result) 
					{
						  if (result.hasOwnProperty(key)) 
						  {
						    console.log(key + " -> " + result[key]);
						    addOption(dropdwn4Obj,key,result[key]);
						  }
					}
					buildHL(selectValue3,dropdwn5Obj,dropdwn6Obj);
		         }
			});
		}
	});
});

$.ajaxSetup({
    error:function(x,e,xhr){
        if(x.status==0){
            alert('You are offline!!\n Please Check Your Network.');
        }else if(x.status==404){
            alert('Requested URL not found.');
        }else if(x.status==500){
            //alert('Internal Server Error.\n'+x.responseText+xhr.responseText);
        	alert(ajaxErrorMsg+" Contact Administrator. \n Reponse code : " + x.status);
        }else if(e=='parsererror'){
            alert('Error.\n Parsing JSON Request failed.');
        }else if(e=='timeout'){
            alert('Request Time out.');
        }else {
        	alert(ajaxErrorMsg+" Contact Administrator. \n Reponse code " + x.status);
            //alert('Unknown Error.\n'+x.responseText);
        }
    }
});

$(document).on({
    ajaxStart: function() { 

    	/* Key measure dropdown population */
    	/*
    	$('#btn3').on('click',function (e){
    		ajaxindicatorstart('Report generation and data retrevial in progress.. \n please wait..');
    	});
    	$('#btn1').on('click',function (e){
    		ajaxindicatorstart('Keymeasure dimension value retrevial in progress.. \n please wait..');
    	});
    	*/
    	//$('#body').addClass("loading");
    	//ajaxindicatorstart('Data retrevial in progress.. \n please wait..');
		console.log("in btn3 ajaxstart : "+ajaxProgressMsg);
    	ajaxindicatorstart(ajaxProgressMsg);
    	
    	},
    ajaxStop: function() { 
    	//$('#body').removeClass("loading");
    	ajaxindicatorstop();
    	}    
});

function ajaxindicatorstart(text)
{
	console.log("in btn3 ajaxstart :text "+text);
	if(jQuery('body').find('#resultLoading').attr('id') != 'resultLoading'){
	jQuery('body').append('<div id="resultLoading" style="display:none"><div><img src="/AjaxTest/images/page-loader.gif"><div>'+text+'</div></div><div class="bg"></div></div>');
	}
	jQuery('#resultLoading').css({
		'width':'100%',
		'height':'100%',
		'position':'fixed',
		'z-index':'10000000',
		'top':'0',
		'left':'0',
		'right':'0',
		'bottom':'0',
		'margin':'auto'
	});
	jQuery('#resultLoading .bg').css({
		'background':'#000000',
		'opacity':'0.7',
		'width':'100%',
		'height':'100%',
		'position':'absolute',
		'top':'0'
	});
	jQuery('#resultLoading>div:first').css({
		'width': '250px',
		'height':'75px',
		'text-align': 'center',
		'position': 'fixed',
		'top':'0',
		'left':'0',
		'right':'0',
		'bottom':'0',
		'margin':'auto',
		'font-size':'16px',
		'z-index':'10',
		'color':'#ffffff'
	});
	jQuery('#resultLoading .bg').height('100%');
	jQuery('#resultLoading').fadeIn(300);
	jQuery('body').css('cursor', 'wait');
}

function ajaxindicatorstop()
{
jQuery('#resultLoading .bg').height('100%');
jQuery('#resultLoading').fadeOut(300);
jQuery('body').css('cursor', 'default');
$("#resultLoading").remove();
}

/*
jQuery(document).ajaxStart(function () {
  //show ajax indicator
  ajaxindicatorstart('loading data.. please wait..');
}).ajaxStop(function () {
//hide ajax indicator
ajaxindicatorstop();
});


If you want to do an specific ajax request without having the loading indicator, you can do it like this by setting global:false
jQuery.ajax({
global: false,
// ajax stuff
});
*/
