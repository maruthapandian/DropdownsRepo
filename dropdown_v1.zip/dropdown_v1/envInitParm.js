var ajaxProgressMsg = "";
var ajaxErrorMsg = ""; 
/* Server name - Essbase Application name Mapping */
var appMap = new Multimap();
//map.set('a', 'three')
appMap.set('ftwlxolpr001','select an option');
//appMap.set('ftwlxolpr001','MDDPRALL');
//appMap.set('ftwlxolpr001','MDDPRCAV');

//appMap.set('ftwlxolpr001','MDDPRCC1');
//appMap.set('ftwlxolpr001','MDDPRCC2');
//appMap.set('ftwlxolpr001','MDDPRCCH');

//appMap.set('ftwlxolpr001','MDDPRCCI');

//appMap.set('ftwlxolpr001','MDDPRCL1');
//appMap.set('ftwlxolpr001','MDDPRCL2');
//appMap.set('ftwlxolpr001','MDDPRCLH');

//appMap.set('ftwlxolpr001','MDDPRCLI');
//appMap.set('ftwlxolpr001','MDDPRCLL');
//appMap.set('ftwlxolpr001','MDDPRCOD');
//appMap.set('ftwlxolpr001','MDDPRCOT');
//appMap.set('ftwlxolpr001','MDDPRCPA');
//appMap.set('ftwlxolpr001','MDDprCrw');
//appMap.set('ftwlxolpr001','MDDPRCTD');

//appMap.set('ftwlxolpr001','MDDPRCV1');
//appMap.set('ftwlxolpr001','MDDPRCV2');

//appMap.set('ftwlxolpr001','MDDPRCVD');
//appMap.set('ftwlxolpr001','MDDPRFul');
//appMap.set('ftwlxolpr001','MDDPRHLD');

//appMap.set('ftwlxolpr001','MDDPRIB1');
//appMap.set('ftwlxolpr001','MDDPRIB2');
//appMap.set('ftwlxolpr001','MDDPRIBH');

//appMap.set('ftwlxolpr001','MDDPRIBU');
//appMap.set('ftwlxolpr001','MDDPRInv');
appMap.set('ftwlxolpr001','MDDprLAv');

//appMap.set('ftwlxolpr001','MDDprLD1');
//appMap.set('ftwlxolpr001','MDDprLD2');
//appMap.set('ftwlxolpr001','MDDprLDH');

appMap.set('ftwlxolpr001','MDDprLDw');
appMap.set('ftwlxolpr001','MDDprLMd');
appMap.set('ftwlxolpr001','MDDPRLST');
appMap.set('ftwlxolpr001','MDDprLUs');
appMap.set('ftwlxolpr001','MDDprLVe');

//appMap.set('ftwlxolpr001','MDDPROTA');
//appMap.set('ftwlxolpr001','MDDPROTB');
//appMap.set('ftwlxolpr001','MDDPROTH');

//appMap.set('ftwlxolpr001','MDDPROTP');
//appMap.set('ftwlxolpr001','MDDPRPPO');
//appMap.set('ftwlxolpr001','MDDprRev');
//appMap.set('ftwlxolpr001','MDDPRSFI');
//appMap.set('ftwlxolpr001','MDDPRSFT');
//appMap.set('ftwlxolpr001','MDDPRTep');

//appMap.set('ftwlxolpr001','MDDPRTP1');
//appMap.set('ftwlxolpr001','MDDPRTP2');

//appMap.set('ftwlxolpr001','MDDPRTPA');
//appMap.set('ftwlxolpr001','MDDprTpf');
//appMap.set('ftwlxolpr001','MDDPRTPH');
//appMap.set('ftwlxolpr001','MDDPRTrn');
//appMap.set('ftwlxolpr001','MDDPRVel');
//appMap.set('ftwlxolpr001','MDDPRYXP');



/* Essbase Application name - Essbase database name Mapping */
var servMap = new Multimap();
servMap.set('MDDPRALL','select an option');
servMap.set('MDDPRALL','dprmeas');
servMap.set('MDDPRCAV','select an option');
servMap.set('MDDPRCAV','MDDPRCAV');
//servMap.set('MDDPRCC1','select an option');
//servMap.set('MDDPRCC1','MDDPRCC1');
//servMap.set('MDDPRCC2','select an option');
//servMap.set('MDDPRCC2','MDDPRCC2');
//servMap.set('MDDPRCCH','select an option');
//servMap.set('MDDPRCCH','MDDPRCCH');
servMap.set('MDDPRCCI','select an option');
servMap.set('MDDPRCCI','MDDPRCCI');
//servMap.set('MDDPRCL1','select an option');
//servMap.set('MDDPRCL1','MDDPRCL1');
//servMap.set('MDDPRCL2','select an option');
//servMap.set('MDDPRCL2','MDDPRCL2');
//servMap.set('MDDPRCLH','select an option');
//servMap.set('MDDPRCLH','MDDPRCLH');
servMap.set('MDDPRCLI','select an option');
servMap.set('MDDPRCLI','MDDPRCLI');
servMap.set('MDDPRCLL','select an option');
servMap.set('MDDPRCLL','MDDPRCLL');
servMap.set('MDDPRCOD','select an option');
servMap.set('MDDPRCOD','MDDPRCOD');
servMap.set('MDDPRCOT','select an option');
servMap.set('MDDPRCOT','MDDPRCOT');
servMap.set('MDDPRCPA','select an option');
servMap.set('MDDPRCPA','MDDPRCPA');
servMap.set('MDDprCrw','select an option');
servMap.set('MDDprCrw','MDDprCrw');
servMap.set('MDDPRCTD','select an option');
servMap.set('MDDPRCTD','MDDPRCTD');
servMap.set('MDDPRCVD','select an option');
servMap.set('MDDPRCVD','MDDPRCVD');
servMap.set('MDDPRFul','select an option');
servMap.set('MDDPRFul','dprfuel');
servMap.set('MDDPRHLD','select an option');
servMap.set('MDDPRHLD','trnhld');
//servMap.set('MDDPRIB1','select an option');
//servMap.set('MDDPRIB1','MDDPRIB1');
//servMap.set('MDDPRIB2','select an option');
//servMap.set('MDDPRIB2','MDDPRIB2');
//servMap.set('MDDPRIBH','select an option');
//servMap.set('MDDPRIBH','MDDPRIBH');
servMap.set('MDDPRIBU','select an option');
servMap.set('MDDPRIBU','MDDPRIBU');
servMap.set('MDDPRInv','select an option');
servMap.set('MDDPRInv','carinv');
servMap.set('MDDprLAv','select an option');
servMap.set('MDDprLAv','MDDprLAv');
servMap.set('MDDprLDw','select an option');
servMap.set('MDDprLDw','MDDprLDw');
servMap.set('MDDprLMd','select an option');
servMap.set('MDDprLMd','MDDprLMd');
servMap.set('MDDPRLST','select an option');
servMap.set('MDDPRLST','MDDPRLST');
servMap.set('MDDprLUs','select an option');
servMap.set('MDDprLUs','MDDprLUs');
servMap.set('MDDprLVe','select an option');
servMap.set('MDDprLVe','MDDprLVe');
servMap.set('MDDPROTP','select an option');
servMap.set('MDDPROTP','otp');
servMap.set('MDDPRPPO','select an option');
servMap.set('MDDPRPPO','MDDPRPPO');
servMap.set('MDDprRev','select an option');
servMap.set('MDDprRev','MDDprRev');
servMap.set('MDDPRSFI','select an option');
servMap.set('MDDPRSFI','MDDPRSFI');
servMap.set('MDDPRSFT','select an option');
servMap.set('MDDPRSFT','MDDPRSFT');
servMap.set('MDDPRTep','select an option');
servMap.set('MDDPRTep','teps');
servMap.set('MDDPRTPA','select an option');
servMap.set('MDDPRTPA','MDDPRTPA');
servMap.set('MDDPRTrn','select an option');
servMap.set('MDDPRTrn','trtnstat');
servMap.set('MDDPRVel','select an option');
servMap.set('MDDPRVel','carvelo');
servMap.set('MDDPRYXP','select an option');
servMap.set('MDDPRYXP','MDDPRYXP');


var mulmap = new Multimap();
//UTIL
mulmap.set("MDDprLUt","0,R1,,BusGrp,,0,0,BNSF SYSTEM");
mulmap.set("MDDprLUt","4,G1,System,SystemRoot,<GEN,3, 2, Regions");
mulmap.set("MDDprLUt","5,G2,System,SystemRoot,<GEN,4, 2, Divisions");
mulmap.set("MDDprLUt","6,G3,Sup,SupRoot,<GEN,3, 2, Superintendents");
mulmap.set("MDDprLUt","8,F1,BusGrp,AllTrainTypes,<GEN,3,2, Loco Train Groups");
mulmap.set("MDDprLUt","9,F2,BusGrp,AllTrainTypes,<GEN,4,2, Loco Train Bus Groups");
mulmap.set("MDDprLUt","10,F3,BusGrp,AllTrainTypes,<GEN,5,2, Loco Train Types");
mulmap.set("MDDprLUt","11,B1,LClass,LClassRoot,<GEN,3,2, Builder Class");
mulmap.set("MDDprLUt","12,B2,LClass,LClassRoot,<GEN,4,2, Loco Class");

//LOCODWELL
mulmap.set("MDDprLDw","0,R1,,BusGrp,,0,0,BNSF SYSTEM");
mulmap.set("MDDprLDw","1,L1,Station,AllLocoDwell,<GEN,3,2, Loco Dwell");
mulmap.set("MDDprLDw","2,L2,Station,AllLocoDwell,<GEN,4,2, Stations");
mulmap.set("MDDprLDw","4,G1,System,SystemRoot,<GEN,3, 2, Regions");
mulmap.set("MDDprLDw","5,G2,System,SystemRoot,<GEN,4, 2, Divisions");
mulmap.set("MDDprLDw","6,G3,Sup,SupRoot,<GEN,3, 2, Superintendents");
mulmap.set("MDDprLDw","8,F1,BusGrp,AllTrainTypes,<GEN,3,2, Loco Train Groups");
mulmap.set("MDDprLDw","9,F2,BusGrp,AllTrainTypes,<GEN,4,2, Loco Train Bus Groups");
mulmap.set("MDDprLDw","10,F3,BusGrp,AllTrainTypes,<GEN,5,2, Loco Train Types");
mulmap.set("MDDprLDw","14,D1,DwellType,AllPairs,<GEN,3,2, Dwell Type");
mulmap.set("MDDprLDw","15,D2,DwellType,AllPairs,<GEN,4,2, Dwell Event Type");

//AVAIL
mulmap.set("MDDprLAv","0,R1,,BusGrp,,0,0,BNSF SYSTEM");
mulmap.set("MDDprLAv","3,E1,ShopLoc,AllLocations,<GEN,3,2, Shop Location");
mulmap.set("MDDprLAv","8,F1,BusGrp,AllTrainTypes,<GEN,3,2, Loco Train Groups");
mulmap.set("MDDprLAv","9,F2,BusGrp,AllTrainTypes,<GEN,4,2, Loco Train Bus Groups");
mulmap.set("MDDprLAv","10,F3,BusGrp,AllTrainTypes,<GEN,5,2, Loco Train Types");
mulmap.set("MDDprLAv","11,B1,LClass,LClassRoot,<GEN,3,2, Builder Class");
mulmap.set("MDDprLAv","12,B2,LClass,LClassRoot,<GEN,4,2, Loco Class");
mulmap.set("MDDprLAv","16,E2,DfctLvl,AllDefects,<GEN,3,2, Defect Level");
mulmap.set("MDDprLAv","17,E3,MaintRespPrty,MaintRespPrty,<GEN,3,2, Maint Responsibility");
mulmap.set("MDDprLAv","22,H1,Locomotives,LocomotivesRoot,<GEN,3,2, Yard-RCO");

//AVGMPD
mulmap.set("MDDprLVe","0,R1,,BusGrp,,0,0,BNSF SYSTEM");
mulmap.set("MDDprLVe","4,G1,System,SystemRoot,<GEN,3, 2, Regions");
mulmap.set("MDDprLVe","5,G2,System,SystemRoot,<GEN,4, 2, Divisions");
mulmap.set("MDDprLVe","6,G3,Sup,SupRoot,<GEN,3, 2, Superintendents");
mulmap.set("MDDprLVe","8,F1,BusGrp,AllTrainTypes,<GEN,3,2, Loco Train Groups");
mulmap.set("MDDprLVe","9,F2,BusGrp,AllTrainTypes,<GEN,4,2, Loco Train Bus Groups");
mulmap.set("MDDprLVe","10,F3,BusGrp,AllTrainTypes,<GEN,5,2, Loco Train Types");
mulmap.set("MDDprLVe","11,B1,LClass,LClassRoot,<GEN,3,2, Builder Class");
mulmap.set("MDDprLVe","12,B2,LClass,LClassRoot,<GEN,4,2, Loco Class");

//LOCOUSGCNT
mulmap.set("MDDprLUs","0,R1,,BusGrp,,0,0,BNSF SYSTEM");
mulmap.set("MDDprLUs","4,G1,System,SystemRoot,<GEN,3, 2, Regions");
mulmap.set("MDDprLUs","5,G2,System,SystemRoot,<GEN,4, 2, Divisions");
mulmap.set("MDDprLUs","6,G3,Sup,SupRoot,<GEN,3, 2, Superintendents");
mulmap.set("MDDprLUs","8,F1,BusGrp,AllTrainTypes,<GEN,3,2, Loco Train Groups");
mulmap.set("MDDprLUs","9,F2,BusGrp,AllTrainTypes,<GEN,4,2, Loco Train Bus Groups");
mulmap.set("MDDprLUs","10,F3,BusGrp,AllTrainTypes,<GEN,5,2, Loco Train Types");
mulmap.set("MDDprLUs","11,B1,LClass,LClassRoot,<GEN,3,2, Builder Class");
mulmap.set("MDDprLUs","12,B2,LClass,LClassRoot,<GEN,4,2, Loco Class");
mulmap.set("MDDprLUs","18,C2,HP,AllHP,<GEN,3,2, HP Group");
mulmap.set("MDDprLUs","18,C3,HP,AllHP,<GEN,4,2, HP Categories");
mulmap.set("MDDprLUs","22,H1,Locomotives,LocomotivesRoot,<GEN,3,2, Yard-RCO");

//LOCOOWNCNT - Loco Status snapshot
mulmap.set("MDDPRLST","0,R1,,BusGrp,,0,0,BNSF SYSTEM");
mulmap.set("MDDPRLST","11,B1,LClass,LClassRoot,<GEN,3,2, Builder Class");
mulmap.set("MDDPRLST","12,B2,LClass,LClassRoot,<GEN,4,2, Loco Class");
mulmap.set("MDDPRLST","19,S1,ServiceType,ServiveTypeRoot,<GEN,3,2, Loco Service Type");
mulmap.set("MDDPRLST","20,S2,Owned,OwnedRoot,<GEN,3,2, Usability");
mulmap.set("MDDPRLST","21,S3,Owned,OwnedRoot,<GEN,4,2, Availabilty");
mulmap.set("MDDPRLST","23,H2,EqpManufacturer,EqpManufacturerRoot,<GEN,3,2, Eqp Manufacturer");


var paramSeq = [""];
var paramJSVal = [""];
var paramDim = [""];
var paramLinkDesc = [""];
var parmEsscmd = [""];
var parmGen = [""];
var paramParentGen = [""];
var englishLevelDesc = [""];


