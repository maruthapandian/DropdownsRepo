var highLevelVal = new Array();
var highLevelDesc = new Array();
//var lowLevelVal = new Array();
//var lowLevelDesc = new Array();

function setDateRange(dbName) {
	var dateVal = new Array(); 
	var dateDesc = new Array();
	var dropdwn4Obj = document.getElementById("combo4");
	var dropdwn5Obj = document.getElementById("combo5");
	var dropdwn6Obj = document.getElementById("combo6");

	dateVal = ["CD-1","CD-2","CD-3","MTD","QTD","YTD","CW","CM-1","CM-2","CM-12","CM-13","CQ-1","CY-1"];
	dateDesc = ["Daily","2 Days Ago","3 Days Ago","Month-to-date","Quarter-to-date","Year-to-date","Last Week","Last Month ","2 Months Ago ","Last Year Current Month ","Last Year Prior Month","Last Quarter ","Last Year"];
	dateVal.unshift("option 0"); dateDesc.unshift("select an option");
	
	for (var i =0;i < dateVal.length;i++)
	{
		addOption(document.getElementById("combo4"),dateVal[i],dateDesc[i]);
	}
	
	buildHL(dbName,dropdwn5Obj,dropdwn6Obj);
}

function buildHL(dbName,dropdwn5Obj,dropdwn6Obj)
{
	console.log("in buildHL");
	//var selectedDropdownoptions = mulmap.get(dbName);
	var selectedDropdownoptions = mulmap.get("MDDprLUs");
	highLevelVal = [];
	highLevelDesc = [];
	//console.log("selectedDropdownoptions : "+selectedDropdownoptions);
	for (var i =0;i < selectedDropdownoptions.length;i++)
	{
		var var1 =  selectedDropdownoptions[i].split(',');
		paramSeq[i] = var1[0];
		paramJSVal[i] = var1[1]; 
		paramDim[i] = var1[2];
		paramLinkDesc[i] = var1[3];
		parmEsscmd[i] = var1[4];
		parmGen[i] = var1[5];
		paramParentGen[i] = var1[6];
		englishLevelDesc[i] = var1[7];
		//addOption(dropdwn5Obj,paramJSVal[i],englishLevelDesc[i]);
	}
	//var var1 =  selectedDropdownoptions[0].split(',');
	//console.log(paramJSVal);
	for(var i =0;i<paramJSVal.length;i++)
	{
		highLevelVal.push(paramJSVal[i]);
		highLevelDesc.push(englishLevelDesc[i]);
	}
	//highLevelDesc = englishLevelDesc;
	addHighLevel(highLevelVal,highLevelDesc,dropdwn5Obj) ;
}

function addHighLevel(highLevelVal,highLevelDesc,dropdwn5Obj) 
{
	 console.log("in combo5 build");
	 dropdwn5Obj.options.length=0;
	 highLevelVal.unshift("option0");
	 highLevelDesc.unshift("select an option");
	 //console.log(highLevelVal);
	 //console.log(highLevelDesc);
	for (var i =0;i < highLevelVal.length;i++)
	{
		addOption(dropdwn5Obj,highLevelVal[i],highLevelDesc[i]);
	}
	
}


function addLowLevel(dropdwn5Obj) 
{	
	 enableElement(document.getElementById('btn2'));
	 var dropdwn6Obj = document.getElementById("combo6");
	 //console.log("in combo6 build");
	 var selectoption = "";
	 dropdwn6Obj.options.length=0;
	 
	 var selectIndex = dropdwn5Obj.selectedIndex;
     //console.log(selectIndex);
     //var selectValue = dropdwn5Obj.options[selectIndex].text;
	 var selecteditem = dropdwn5Obj.options[selectIndex].value;
	 console.log("selecteditem "+selecteditem);
	 //console.log(selectValue);
	 
	 var lowLevelVal = new Array();
	 var lowLevelDesc = new Array();
	// lowLevelVal = paramJSVal;
	 //lowLevelDesc = englishLevelDesc;
	 
	// console.log("paramJSVal : "+paramJSVal);
	 //console.log("englishLevelDesc : "+englishLevelDesc);
	 
	/* 
	 for(var i = 0; i<englishLevelDesc.length;i++ )
	 {
		if(selectValue == englishLevelDesc[i])
		{	
				 //console.log("englishLevelDesc : "+englishLevelDesc[i]);
				//  console.log("paramJSVal : "+paramJSVal[i]);
				selectoption = paramJSVal[i];
				break;
		}
	 }
	 console.log("selectoption : "+selectoption);
	 console.log("iteration starts");
	 */
	 if(selecteditem != "option0")
	 {
	 
		 for(var i = 0;i< paramJSVal.length;i++)
		 {
			lowLevelVal.push(paramJSVal[i]);
			lowLevelDesc.push(englishLevelDesc[i]);
		 }
		 
		//console.log(" length of lowLevelVal : "+lowLevelVal.length);
		//console.log(" length of paramJSVal : "+paramJSVal.length);
		for(var i = 0; i<lowLevelVal.length;i++ )
		{		
				//console.log("iteration "+i+" "+lowLevelVal[i]);
				if(selecteditem == lowLevelVal[i])
				{
					//console.log(" to be spliced in if part lowLevelVal[i] : "+lowLevelVal[i]);
					lowLevelVal.splice(i,1);
					lowLevelDesc.splice(i,1);
					i--;
				}
				//else if((substr(selectValue,1,1) == substr(lowLevelVal[i],1,1)) && (substr(selectValue,2,1) < substr(lowLevelVal[i],2,1))) 
				else if((selecteditem.substr(0,1) == lowLevelVal[i].substr(0,1)) && (selecteditem.substr(1,1) > lowLevelVal[i].substr(1,1))) 
				{
					
					//console.log(" selecteditem.substr(1,1): "+selecteditem.substr(0,1));
					//console.log(" tlowLevelVal[i].substr(1,1) : "+lowLevelVal[i].substr(0,1));
					//console.log(" selecteditem.substr(2,1): "+selecteditem.substr(1,1));
					//console.log(" lowLevelVal[i].substr(2,1) : "+lowLevelVal[i].substr(1,1));
					//console.log(" to be spliced in else if part lowLevelVal[i] : "+lowLevelVal[i]);
					lowLevelVal.splice(i,1);
					lowLevelDesc.splice(i,1);
					i--;
				}
				//console.log("End of iteration: "+lowLevelVal);
				//console.log(" length of lowLevelVal end iteration : "+lowLevelVal.length);
		}
		 
		 lowLevelVal.unshift("option0");
		 lowLevelDesc.unshift("select an option");
		 //console.log(lowLevelVal);
		for (var i =0;i < lowLevelVal.length;i++)
		{
			addOption(dropdwn6Obj,lowLevelVal[i],lowLevelDesc[i]);
		}
	}
}
