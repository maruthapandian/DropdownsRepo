package servletHandler;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ReportServletHandler
 */
public class ReportServletHandler extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ReportServletHandler() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String reportQuery = "";
		System.out.println(request.getContextPath());
		System.out.println(reportQuery);
		String str = "";
		PrintWriter out = response.getWriter();
		   Enumeration paramNames = request.getParameterNames();
		      
		      while(paramNames.hasMoreElements()) {
		         String paramName = (String)paramNames.nextElement();
		       //  out.print("<tr><td>" + paramName + "</td>\n<td>");
		         System.out.println("paramName : "+paramName);
		         String[] paramValues =
		                request.getParameterValues(paramName);
		         // Read single valued data
		         if (paramValues.length == 1) {
		           String paramValue = paramValues[0];
		           
		           if (paramValue.length() == 0)
		        	   System.out.println("paramValues : "+"No Value");
		             //out.println("<i>No Value</i>");
		           else
		        	   //System.out.println("paramValues : "+Arrays.toString(paramValues));   
		        	   System.out.println("paramValues : "+paramValue);
		          // dbname = paramValue.substring(1,(paramValue.length()-1));
		           reportQuery = paramValue;
		             //out.println(paramValue);
		         } else {
		             // Read multiple valued data
		             for(int i=0; i < paramValues.length; i++) {
		            	 System.out.println("paramValues : ["+i+"] : "+paramValues[i]);   		       
		             }
		         }
		      }
		      System.out.println(reportQuery);
		try{
			Thread.sleep(3000);                 //1000 milliseconds is one second.
			str = "This is demo ajax call";		
		}
		catch(InterruptedException ex) {
		    Thread.currentThread().interrupt();
			str = "Issue in data retrevial. Contact Administrator";
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR ,str);
			//e.printStackTrace();
		}
		catch(Exception e)
		{
			
			str = "Issue in data retrevial. Contact Administrator";
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR ,str);
			e.printStackTrace();
		}

		out.append(str);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
