package servletHandler;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.tribes.util.Arrays;
import org.json.*;

/**
 * Servlet implementation class DropDownHandler
 */
public class DropDownHandler extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DropDownHandler() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String dbname = "";
		System.out.println(request.getContextPath());
		System.out.println(dbname);
		PrintWriter out = response.getWriter();
		response.setContentType("application/json");
		JSONObject keyDimVal = new JSONObject();
		try
		{
			Thread.sleep(3000);
		}
		catch(InterruptedException ex) {
		    Thread.currentThread().interrupt();
		    try {
		    	System.out.println("In InterruptedException exception 1");
				keyDimVal.put("Exception", "Issue in data retrevial. Contact Administrator");
				response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR ,keyDimVal.getString("Exception"));
				ex.printStackTrace();
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		/*
		dbname = request.getParameter("data");
		System.out.println(dbname);
		if(dbname == null){
			dbname = "A";
		}
		//
		 */
		
		   Enumeration paramNames = request.getParameterNames();
		      
		      while(paramNames.hasMoreElements()) {
		         String paramName = (String)paramNames.nextElement();
		       //  out.print("<tr><td>" + paramName + "</td>\n<td>");
		         System.out.println("paramName : "+paramName);
		         String[] paramValues =
		                request.getParameterValues(paramName);
		         // Read single valued data
		         if (paramValues.length == 1) {
		           String paramValue = paramValues[0];
		           
		           if (paramValue.length() == 0)
		        	   System.out.println("paramValues : "+"No Value");
		             //out.println("<i>No Value</i>");
		           else
		        	   //System.out.println("paramValues : "+Arrays.toString(paramValues));   
		        	   System.out.println("paramValues : "+paramValue);
		          // dbname = paramValue.substring(1,(paramValue.length()-1));
		           dbname = paramValue;
		             //out.println(paramValue);
		         } else {
		             // Read multiple valued data
		             for(int i=0; i < paramValues.length; i++) {
		            	 System.out.println("paramValues : ["+i+"] : "+paramValues[i]);   		       
		             }
		         }
		      }
		      System.out.println(dbname);
		try {
			
			if(dbname.equalsIgnoreCase("MDDprLUs"))
			{
				keyDimVal.put("four4", "four");
				keyDimVal.put("five5", "five");
				keyDimVal.put("six6", "six");
			}
			else
			{
				keyDimVal.put("one1", "one");
				keyDimVal.put("two2", "two");
				keyDimVal.put("three3", "three");	
				System.out.println("In else : "+keyDimVal.toString());
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			try {
				System.out.println("In JSON exception 1");
				keyDimVal.put("Exception", "Issue in data retrevial. Contact Administrator");
				response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR ,keyDimVal.getString("Exception"));
				e.printStackTrace();
			} catch (JSONException e1) {
				System.out.println("In JSON exception 1");
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		}
		catch(Exception ex) {
		    try {
		    	System.out.println("In Exception exception 1");
				keyDimVal.put("Exception", "Issue in data retrevial. Contact Administrator");
				response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR ,keyDimVal.getString("Exception"));
				ex.printStackTrace();
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//e.printStackTrace();
		}
		System.out.println("Final out : "+keyDimVal.toString());
		out.print(keyDimVal);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
